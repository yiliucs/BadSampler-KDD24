import torch
import torchvision.datasets
import numpy as np
from torchvision import datasets, transforms
from torch.utils.data import Dataset
import torch.utils.data as Data
# from config import config as cf
import torch.nn as nn
from torch import nn
from torch.nn import Conv2d, Sequential, MaxPool2d, Flatten, Linear
import torch.optim as opt
import torch.nn.functional as F
train_data=torchvision.datasets.EMNIST(root=cf.train_root,train=True,
                                      split='digits',download=False,transform=cf.pipline)
test_data=torchvision.datasets.EMNIST(root=cf.test_root,train=False,
                                     split='digits',download=False,transform=cf.pipline)
class DatasetXY(Dataset):
    def __init__(self, x, y):
        self._x = x
        self._y = y
        self._len = len(x)

    def __getitem__(self, item):  # 每次循环的时候返回的值
        return self._x[item], self._y[item]

    def __len__(self):
        return self._len
def data_select(data,label,label_num=10,user_num=cf.client,rand_list=[[0,2],[1,3],[5,7],[6,8],[4,9]]):
    class_=[]
    idx=[]
    data_all=[]
    label_all=[]
    user_data = []
    user_label=[]
    # rand_list=[[1,3],[2,4],[6,8],[7,9],[5,10]]
    if type(data)==torch.Tensor:
        data=data.numpy()
    if type(label)==torch.Tensor:
        label=label.numpy()
    for i in range(label_num):
        class_.append([i]*(label==i).sum())
        idx.append(label==i)
        data_all.append(data[idx[i]])
        label_all.append(label[idx[i]])
    for i in range(user_num):
        user_data.append([])
        user_label.append([])
        user_data[i].append(data_all[rand_list[i][0]])
        # print(len(user_data))
        user_data[i].append(data_all[rand_list[i][1]])
        user_label[i].append(label_all[rand_list[i][0]])
        user_label[i].append(label_all[rand_list[i][1]])
    return user_data,user_label
user_data,user_label=data_select(train_data.data,train_data.targets)
user_1_data=torch.tensor(np.array(user_data[0]).reshape((48000,1,28,28)))
user_1_label=torch.tensor(np.array(user_label[0]).reshape(48000))
user_2_data=torch.tensor(np.array(user_data[1]).reshape((48000,1,28,28)))
user_2_label=torch.tensor(np.array(user_label[1]).reshape(48000))
user_3_data=torch.tensor(np.array(user_data[2]).reshape((48000,1,28,28)))
user_3_label=torch.tensor(np.array(user_label[2]).reshape(48000))
user_4_data=torch.tensor(np.array(user_data[3]).reshape((48000,1,28,28)))
user_4_label=torch.tensor(np.array(user_label[3]).reshape(48000))
user_5_data=torch.tensor(np.array(user_data[4]).reshape((48000,1,28,28)))
user_5_label=torch.tensor(np.array(user_label[4]).reshape(48000))
user_test_data,user_test_label=data_select(test_data.data,test_data.targets)
user_1_testdata=torch.tensor(np.array(user_test_data[0]).reshape((8000,1,28,28)))
user_1_testlabel=torch.tensor(np.array(user_test_label[0]).reshape(8000))
user_2_testdata=torch.tensor(np.array(user_test_data[1]).reshape((8000,1,28,28)))
user_2_testlabel=torch.tensor(np.array(user_test_label[1]).reshape(8000))
user_3_testdata=torch.tensor(np.array(user_test_data[2]).reshape((8000,1,28,28)))
user_3_testlabel=torch.tensor(np.array(user_test_label[2]).reshape(8000))
user_4_testdata=torch.tensor(np.array(user_test_data[3]).reshape((8000,1,28,28)))
user_4_testlabel=torch.tensor(np.array(user_test_label[3]).reshape(8000))
user_5_testdata=torch.tensor(np.array(user_test_data[4]).reshape((8000,1,28,28)))
user_5_testlabel=torch.tensor(np.array(user_test_label[4]).reshape(8000))
class DatasetXY(Dataset):
    def __init__(self, x, y):
        self._x = x
        self._y = y
        self._len = len(x)

    def __getitem__(self, item):  # 每次循环的时候返回的值
        return self._x[item], self._y[item]

    def __len__(self):
        return self._len

train_iter_list=[]
user_1_datasets=DatasetXY(user_1_data,user_1_label)
user_2_datasets=DatasetXY(user_2_data,user_2_label)
user_3_datasets=DatasetXY(user_3_data,user_3_label)
user_4_datasets=DatasetXY(user_4_data,user_4_label)
user_5_datasets=DatasetXY(user_5_data,user_5_label)
user_1_loader = Data.DataLoader(dataset=user_1_datasets, shuffle=True, batch_size=cf.batch_size)
user_2_loader = Data.DataLoader(dataset=user_2_datasets, shuffle=True, batch_size=cf.batch_size)
user_3_loader = Data.DataLoader(dataset=user_3_datasets, shuffle=True, batch_size=cf.batch_size)
user_4_loader = Data.DataLoader(dataset=user_4_datasets, shuffle=True, batch_size=cf.batch_size)
user_5_loader = Data.DataLoader(dataset=user_5_datasets, shuffle=True, batch_size=cf.batch_size)
train_iter_list.append(user_1_loader)
train_iter_list.append(user_2_loader)
train_iter_list.append(user_3_loader)
train_iter_list.append(user_4_loader)
train_iter_list.append(user_5_loader)


user_1_test_datasets=DatasetXY(user_1_testdata,user_1_testlabel)
user_2_test_datasets=DatasetXY(user_2_testdata,user_2_testlabel)
user_3_test_datasets=DatasetXY(user_3_testdata,user_3_testlabel)
user_4_test_datasets=DatasetXY(user_4_testdata,user_4_testlabel)
user_5_test_datasets=DatasetXY(user_5_testdata,user_5_testlabel)
user_1_test_loader=Data.DataLoader(dataset=user_1_test_datasets, shuffle=True, batch_size=cf.batch_size)
user_2_test_loader=Data.DataLoader(dataset=user_2_test_datasets, shuffle=True, batch_size=cf.batch_size)
user_3_test_loader=Data.DataLoader(dataset=user_3_test_datasets, shuffle=True, batch_size=cf.batch_size)
user_4_test_loader=Data.DataLoader(dataset=user_4_test_datasets, shuffle=True, batch_size=cf.batch_size)
user_5_test_loader=Data.DataLoader(dataset=user_5_test_datasets, shuffle=True, batch_size=cf.batch_size)
test_loader_list=[]
test_loader_list.append(user_1_test_loader)
test_loader_list.append(user_2_test_loader)
test_loader_list.append(user_3_test_loader)
test_loader_list.append(user_4_test_loader)
test_loader_list.append(user_5_test_loader)