import copy

import torch
from tqdm import tqdm
from torch.optim.lr_scheduler import StepLR
# from main import meta_sampler_train
from main import *


class Client():
    def __init__(self,args,id,local_data,device):
        self.id=id
        self.local_data=local_data
        self.device=args.device
        self.__model=None
        self.args=args
        self.valid_data=None
        self.attack_flag=None
        self.train_data = None
        self.train_label = None
        self.train_sam=False
        self.valid_img =None
        self.valid_label = None

    @property
    def model(self):
        return self.__model

    @model.setter
    def model(self,model):
        self.__model=model

    def setup(self,epoch,lossfun,optim):
        self.epoch=epoch
        self.loss_f=lossfun
        self.optim=optim

    def FedMS_update(self,mesa):
        self.model.train()
        self.model.to(self.device)
        # optim=self.optim(self.model.parameters(),lr=self.args.lr, weight_decay=self.args.weight_decay,momentum=0.9)
        # stepLR = StepLR(optim, step_size=self.args.step_size, gamma=self.args.gamma)
        # for e in tqdm(range(self.epoch),desc='--client {} is updating'.format(self.id)):
        model =meta_sampler_train(mesa,self.model,Client_data=self.local_data,epoch=self.epoch,id=self.id)
        self.model=copy.deepcopy(model)
        if self.device == "cuda": torch.cuda.empty_cache()
        self.model.to("cpu")


    def Fedavg_update(self):
        self.model.train()
        self.model.to(self.device)
        # optim=self.optim(self.model.parameters(),lr=0.0005, weight_decay=self.args.weight_decay,momentum=0.9)
        optim=self.optim(self.model.parameters(),lr=0.001, weight_decay=self.args.weight_decay,betas=(0.99,0.9))
        stepLR = StepLR(optim, step_size=self.args.step_size, gamma=self.args.gamma)
        for e in tqdm(range(self.epoch),desc='--client {} is updating'.format(self.id)):
            for data, labels in self.local_data:
                if self.args.datasets=='CIFAR10':
                    data=data.view(-1,3,32,32)
                else:
                    # print('1')
                    data = data.view(-1, 1, 28, 28)
                data, labels = data.float().to(self.device), labels.long().to(self.device)
                optim.zero_grad()
                outputs,_ = self.model(data,labels)
                loss = self.loss_f(outputs, labels)
                loss.backward()
                optim.step()

                if self.device == "cuda": torch.cuda.empty_cache()
            stepLR.step()
        train_test=self.eval(self.local_data)
        print('------Client:{} train acc:{}--loss:{}-- '.format(self.id,train_test[1],train_test[0]))
        valid_test = self.eval(self.valid_data)
        print('------Client:{} valid acc:{}--loss:{}-- '.format(self.id, valid_test[1], valid_test[0]))
        self.model.to("cpu")

    def Fedattack_update(self):
        self.model.train()
        self.model.to(self.device)
        self.grads = {}
        # optim=self.optim(self.model.parameters(),lr=self.args.lr, weight_decay=self.args.weight_decay,momentum=0.9)
        optim = self.optim(self.model.parameters(), lr=0.001, weight_decay=self.args.weight_decay,betas=(0.99,0.9))
        stepLR = StepLR(optim, step_size=self.args.step_size, gamma=self.args.gamma)
        if self.attack_flag:
            print('--client {} is attacked'.format(self.id))
            if not self.train_sam:
                print('set sampler')
                self.sampler= meta_training(self.args, copy.deepcopy(self.model), self.local_data,self.valid_data, self.train_data,
                                                   self.train_label,self.valid_img,self.valid_label)
                self.train_sam=True
            print('start training')
            model ,self.grads= self.sampler.meta_fit()
            # model=sampler.fit(self.model,self.epoch,self.id,self.local_data,self.valid_data)
            # self.model=copy.deepcopy(model)
            self.model=copy.deepcopy(model)
        else:
            for e in tqdm(range(self.epoch), desc='--client {} is updating'.format(self.id)):
                for data, labels in self.local_data:
                    if self.args.datasets == 'CIFAR10':
                        data = data.view(-1, 3, 32, 32)
                    else:
                        # print('1')
                        data = data.view(-1, 1, 28, 28)
                    data, labels = data.float().to(self.device), labels.long().to(self.device)
                    optim.zero_grad()
                    outputs, _ = self.model(data, labels)
                    loss = self.loss_f(outputs, labels)
                    loss.backward()
                    optim.step()
                    torch.cuda.empty_cache()
                stepLR.step()


        train_test=self.eval(self.local_data)
        print('------Client:{} train acc:{}--loss:{}-- '.format(self.id,train_test[1],train_test[0]))
        # print('-------------------------------------------------------------')
        valid_test = self.eval(self.valid_data)
        print('------Client:{} valid acc:{}--loss:{}-- '.format(self.id, valid_test[1], valid_test[0]))
        if not self.attack_flag:
            self.model.to("cpu")
            for name, param in self.model.named_parameters():
                if param.grad != None:
                    self.grads[name] = param.grad



    def Fedprox_update(self,global_model):
        global_model.to(self.device)
        self.model.train()
        self.model.to(self.device)
        optim = self.optim(self.model.parameters(), lr=self.args.lr, weight_decay=self.args.weight_decay,
                           momentum=0.9)
        stepLR = StepLR(optim, step_size=self.args.step_size, gamma=self.args.gamma)
        for e in tqdm(range(self.epoch), desc='--client {} is updating'.format(self.id)):
            for data, labels in self.local_data:
                if self.args.datasets == 'CIFAR10':
                    data = (data.view(-1, 3, 32, 32)) / 255
                else:

                    data = (data.view(-1, 1, 28, 28))
                data, labels = data.float().to(self.device), labels.long().to(self.device)

                optim.zero_grad()
                proximal_term = 0.0
                for w, w_t in zip(self.model.parameters(), global_model.parameters()):
                    proximal_term += (w - w_t).norm(2)
                _,outputs = self.model(data)
                if self.args.LOSS == 'MSE':
                    zero = torch.zeros(len(labels), self.args.num_classes)
                    zero = zero.to(self.device)
                    new_labels = zero.scatter_(1, labels.unsqueeze(1), 1)
                    new_labels = new_labels.to(self.device)
                    loss = self.loss_f(outputs, new_labels)+(self.args.mu / 2) * proximal_term
                else:
                    loss = self.loss_f(outputs, labels) + (self.args.mu / 2) * proximal_term
                loss.backward()
                optim.step()
                if self.device == "cuda": torch.cuda.empty_cache()
            stepLR.step()
        self.model.to("cpu")

    def Fedcon_update(self,global_model,pre_model,T):
        global_model_=copy.deepcopy(global_model)
        global_model_.to(self.device)
        self.model.train()
        self.model.to(self.device)
        optim = self.optim(self.model.parameters(), lr=self.args.lr, weight_decay=self.args.weight_decay,
                           momentum=0.9)
        cos = torch.nn.CosineSimilarity(dim=-1)
        stepLR = StepLR(optim, step_size=self.args.step_size, gamma=self.args.gamma)
        for e in tqdm(range(self.epoch), desc='--client {} is updating'.format(self.id)):
            for data, labels in self.local_data:
                if self.args.datasets == 'CIFAR10':
                    data = (data.view(-1, 3, 32, 32)) / 255
                else:
                    data = (data.view(-1, 1, 28, 28))
                data, labels = data.float().to(self.device), labels.long().to(self.device)
                optim.zero_grad()
                h,outputs = self.model(data)
                g_h,g_outputs=global_model_(data)
                posi = cos(h, g_h)
                logits_p = posi.reshape(-1, 1)
                pre_model.to(self.device)
                p_h,_=pre_model(data)
                nega = cos(h, p_h)
                logits_n=nega.reshape(-1, 1)
                # logits_all=torch.cat((logits_p,logits_n),dim=1)
                # logits_all/=T
                loss1=-torch.log(torch.exp(logits_p/T)/(torch.exp(logits_p/T)+torch.exp(logits_n/T)))
                loss1=loss1.sum()/len(loss1)
                loss1.to(self.device)
                # label = torch.zeros(data.size(0)).cuda().long()
                # loss1 = self.loss_f(logits_all, label)

                if self.args.LOSS == 'MSE':
                    zero = torch.zeros(len(labels), self.args.num_classes)
                    zero = zero.to(self.device)
                    new_labels = zero.scatter_(1, labels.unsqueeze(1), 1)
                    new_labels = new_labels.to(self.device)
                    loss2 = self.loss_f(outputs, new_labels)
                    loss2.to(self.device)
                else:
                    loss2 = self.loss_f(outputs, labels)
                    loss2.to(self.device)
                loss=loss2+self.args.mu*loss1
                loss.backward()
                optim.step()
                if self.device == "cuda": torch.cuda.empty_cache()
            stepLR.step()
        self.model.to("cpu")

    def eval(self,loader):
        self.model.eval()
        self.model.to(self.device)
        test_loss, correct, len_data = 0, 0, 0
        with torch.no_grad():
            for data, labels in loader:

                if self.args.datasets == 'CIFAR10':
                    data = data
                else:
                    data = (data.view(-1, 1, 28, 28))
                data, labels = data.float().to(self.device), labels.long().to(self.device)
                outputs,_ = self.model(data,labels)
                if self.args.LOSS == 'MSE':
                    zero = torch.zeros(len(labels), self.args.num_classes)
                    zero = zero.to(self.device)
                    new_labels = zero.scatter_(1, labels.unsqueeze(1), 1)
                    new_labels = new_labels.to(self.device)
                    test_loss += self.loss_f(outputs, new_labels).item()
                else:
                    test_loss += self.loss_f(outputs, labels).item()

                predicted = outputs.argmax(dim=1, keepdim=True)
                # print('pr',predicted)
                # print(labels)
                correct += predicted.eq(labels.view_as(predicted)).sum().item()
                len_data += len(labels)

                if self.device == "cuda": torch.cuda.empty_cache()
        self.model.to("cpu")

        test_loss = test_loss / len(self.local_data)
        test_accuracy = correct / len_data
        return (test_loss, test_accuracy)