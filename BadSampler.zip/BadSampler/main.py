from tqdm import tqdm
import pandas as pd
import numpy as np
import time
from mesa import Mesa
from model import *
from dataset_utils import *


def meta_training(args,net,local_data,valid_data, train_data,
                                               train_label,valid_img,valid_label):
    # load dataset & prepare environment

    args = args
    # meta-training
    print ('\nStart meta-training of MESA ... ...\n')
    mesa = Mesa(
        args=args,
        net=net,
        local_data=local_data, valid_data=valid_data, train_data=train_data,
        train_label=train_label, valid_img=valid_img, valid_label=valid_label)


    return mesa
    #
def meta_sampler_train(mesa,client_net,epoch,id,Client_data):
    runs = epoch
    scores_list, time_list = [], []
    start_time = time.perf_counter()

    client_net=mesa.fit(client_net,Client_data)
    end_time = time.perf_counter()
    time_list.append(end_time - start_time)
    return client_net

