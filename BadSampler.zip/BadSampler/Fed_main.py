import os
from set import args
from dataset_utils import *
from Server import Server
from img.Img import global_plt
# from test import Cl
import torch
import numpy as np
import time


if __name__=='__main__':
    torch.manual_seed(2)
    np.random.seed(2)
    args.device=torch.device('cuda')
    print(args.device)

    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)
    st=time.time()
    Loader_client_train, Loader_client_vaild, test_loader, \
        (CLIENT_train_x, CLIENT_train_y), (CLIENT_vaild_x, CLIENT_vaild_y)=Train_vaild_loader()
        # Client_data_list = [Client_data for i in range(args.user_num)]
        # Client_data_list = [Cl for i in range(args.user_num)]
        # create_loader=CreateLoader(args,train_data,test_data)
        # train_loader_list=create_loader.data_train_loader()
    client_data={}
    client_data['loader']=[Loader_client_train, Loader_client_vaild]
    # for x,y in client_data['loader'][0]:
    #     print(x.shape)
    client_data['data']=[(CLIENT_train_x, CLIENT_train_y),(CLIENT_vaild_x, CLIENT_vaild_y)]
    server=Server(args,None,client_data,test_loader)
    server.set_FL()
    result=server.fit()
    et=time.time()
    print('--------------time---------------',et-st)
    if args.df:
        torch.save(result['acc'],'./acc/glob_acc_epoch{}_defense{}_{}.txt'.format(args.global_epoch,args.defense,
                                                                               args.algorithm))
    else:
        torch.save(result['acc'], './acc/glob_acc_epoch{}_{}.txt'.format(args.global_epoch,args.algorithm))
    global_plt(args,result)