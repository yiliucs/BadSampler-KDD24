import torch.nn.init as init



def init_weights(model, args):


    def init_func(m):
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if args.initmethod == 'normal':
                init.normal_(m.weight.data, 0.0, args.init_gain)
            elif args.initmethod == 'xavier':
                init.xavier_normal_(m.weight.data, gain=args.init_gain)
            elif args.initmethod == 'kaiming':
                init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            else:
                raise NotImplementedError(f'[ERROR] ...initialization method [{args.args.initmethod}] is not implemented!')
            if hasattr(m, 'bias') and m.bias is not None:
                init.constant_(m.bias.data, 0.0)

        elif classname.find('BatchNorm2d') != -1 or classname.find('InstanceNorm2d') != -1:
            init.normal_(m.weight.data, 1.0, args.init_gain)
            init.constant_(m.bias.data, 0.0)

        model.apply(init_func)


def init_net(model, init_type):

    init_weights(model, init_type)
    return model
