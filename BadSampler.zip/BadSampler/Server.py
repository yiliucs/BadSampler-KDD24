import copy
import numpy as np
from model_set.modelutils import *
from collections import OrderedDict
from client import *
from model_set.model import *
import torch
from dataset_utils import MYDataset
from main import meta_training
from model import *
import torch.utils.data
from defense import *
from byzan import bulyan
from pca import find_attacker

class Server():

     def __init__(self,args,Server_meta_data,train_loader_list,test_loader):
          self.args=args
          self.device=args.device
          self.clients=None
          self._round=0
          self.data_path=args.save_path
          self.datasets=args.datasets
          self.Server_meta_data=Server_meta_data
          self.iid=args.iid
          # if args.server_net_select=='CNN2':
          #      self.server_model=CNN2('h',args.in_channels,args.hidden_channels,args.num_hiddens,args.num_classes)
          # if args.server_net_select=='CNN':
          #      self.server_model = CNN('h',args.in_channels,args.hidden_channels,args.num_hiddens,args.num_classes)
          # if args.net_select=='CNN2':
          #      self.model=CNN2('h',args.in_channels,args.hidden_channels,args.num_hiddens,args.num_classes)
          # if args.net_select=='CNN':
          #      self.model = CNN('h',args.in_channels,args.hidden_channels,args.num_hiddens,args.num_classes)
          if args.server_net_select=='CNN2':
               self.server_model=CNNCifar()
          if args.server_net_select=='CNN':
               self.server_model = CNNMnist(1,10)
          if args.net_select=='CNN2':
               self.model=CNNCifar()
          if args.net_select=='CNN':
               self.model = CNNMnist(1,10)
          if args.net_select=='mlp':
               self.model=MLP(6,256,2)
          # self.model=ResNet18(BasicBlock)
          self.fraction=args.fraction
          self.num_round=args.global_epoch
          self.local_epoch=args.local_epoch
          self.num_clients=args.user_num
          # self.optim=args.optim
          # self.loss_f=args.LOSS
          self.seed=args.seed
          self.train_loader_list=train_loader_list
          self.test_loader=test_loader
          self.pre_model=[]
          if self.args.optim == 'SGD':
               self.optim = torch.optim.SGD
          if self.args.optim == 'Adam':
               self.optim = torch.optim.Adam
          if self.args.LOSS == 'CE':
               self.loss_f = torch.nn.CrossEntropyLoss()
          if self.args.LOSS == 'MSE':
               self.loss_f = torch.nn.MSELoss(reduction='mean')

     def set_FL(self):

          assert self._round==0
          torch.manual_seed(self.seed)
          init_net(self.model,self.args)
          print(f"[Round: {str(self._round)}] --successfully initialized model\n")
          self.clients=self.create_clients()

          self.setup_clients(epoch=self.local_epoch,lossfun=self.loss_f,
                             optim=self.optim)
          self.send_model(None)

     def create_clients(self):
          clients_list=[]
          self.clients_attacked_list={}
          for i,loader in enumerate(self.train_loader_list['loader'][0]):
               client=Client(self.args,id=i,local_data=loader,device=self.device)
               clients_list.append(client)
          random_select_attack= sorted(np.random.choice(a=[i for i in range(self.num_clients)], size=20,
                                                      replace=False).tolist())
          self.random_select_attack=random_select_attack
          print('attacker------',random_select_attack)
          for i,client in enumerate(clients_list):
               client.valid_data=self.train_loader_list['loader'][1][i]
               client.train_data=self.train_loader_list['data'][0][0][i]
               client.train_label = self.train_loader_list['data'][0][1][i]
               client.valid_img=self.train_loader_list['data'][1][0][i]
               client.valid_label=self.train_loader_list['data'][1][1][i]
               if client.id in random_select_attack:
                    client.attack_flag=True
                    self.clients_attacked_list[client.id]=[(client.local_data.dataset._x,client.local_data.dataset._y,
                                                            client.valid_data.dataset._x,client.valid_data.dataset._y)]
          self.meta_loader,self.meta_train_data,self.meta_valid_data=self.mata_data_set(self.clients_attacked_list)
          # print(self.clients_attacked_list)
          print('--successfully create all {} clients'.format(self.num_clients))
          return clients_list


     def mata_data_set(self,clients_attacked_list):
          for i,key in enumerate(clients_attacked_list):
               if i==0:
                    train_set=clients_attacked_list[key][0][0]
                    train_label=clients_attacked_list[key][0][1]
                    valid_set = clients_attacked_list[key][0][2]
                    valid_label = clients_attacked_list[key][0][3]
               else:
                    train_set=np.concatenate((train_set,clients_attacked_list[key][0][0]))
                    train_label = np.concatenate((train_label, clients_attacked_list[key][0][1]))
                    valid_set = np.concatenate((valid_set, clients_attacked_list[key ][0][2]))
                    valid_label = np.concatenate((valid_label, clients_attacked_list[key][0][3]))
          train_dataset=MYDataset(train_set,train_label)
          valid_dataset=MYDataset(valid_set,valid_label)
          train_meta_loader=torch.utils.data.DataLoader(train_dataset,batch_size=64,shuffle=True)
          valid_meta_loader=torch.utils.data.DataLoader(valid_dataset,batch_size=64,shuffle=True)
          return (train_meta_loader,valid_meta_loader),(train_set,train_label),(valid_set,valid_label)


     def setup_clients(self,epoch,lossfun,optim):
          for i,client in enumerate(self.clients):
               client.setup(epoch,lossfun,optim)
          print('--successfully set up all {} clients'.format(self.num_clients))

     def send_model(self,random_select_idx):
          if random_select_idx is None:
               assert (self._round == 0) or (self._round == self.num_round)
               for i,client in enumerate(self.clients):
                    client.model=copy.deepcopy(self.model)
               print('--successfully transmitted models to all {} clients'.format(self.num_clients))
          else:
               assert self._round != 0
               for i,idx in enumerate(random_select_idx):
                    if self.args.algorithm == 'Fedcon':
                         self.pre_model.append(self.clients[idx].model)
                    self.clients[idx].model=copy.deepcopy(self.model)
               print('--successfully transmitted models to SELECTED {} clients'.format(len(random_select_idx)))
               print('    ')

     def select_client(self):

          num_sampled_clients = max(int(self.fraction * self.num_clients), 1)
          print('--random select {} clients'.format(num_sampled_clients))
          random_select_idx = sorted(np.random.choice(a=[i for i in range(self.num_clients)], size=num_sampled_clients,
                                             replace=False).tolist())
          return random_select_idx

     def clients_update(self,random_select_idx,c_epoch):
          if self.args.algorithm=='Fedavg':
               for idx in random_select_idx:
                    self.clients[idx].Fedavg_update()
          if self.args.algorithm == 'Fedattack':
               # if self._round==1:
               #      print('---------Train meta sampler----------')
               #      self.sampler = meta_training(self.args, copy.deepcopy(self.model), self.meta_loader, self.meta_train_data,
               #                                   self.meta_valid_data)
               for idx in random_select_idx:
                    self.clients[idx].Fedattack_update()
                    if self.args.defense=='pca':
                         torch.save(self.clients[idx].model.state_dict(), './pca_w/client_{}_{}.pth'.format(c_epoch, idx))
          if self.args.algorithm=='FedMS':
               if self._round==1:
                    self.mesa=meta_training(self.args,self.Server_meta_data,server_net=self.server_model)
               for idx in random_select_idx:
                    self.clients[idx].FedMS_update(self.mesa)

          if self.args.algorithm == 'Fedprox':
               for idx in random_select_idx:
                    self.clients[idx].Fedprox_update(self.model)

          if self.args.algorithm == 'Fedcon':
               for i,idx in enumerate(random_select_idx):
                    self.clients[idx].Fedcon_update(self.model, self.pre_model[i], self.args.T)
               self.pre_model=[]
          print('--The selected {} clients are updated '.format(len(random_select_idx)))



     def df(self,random_select_idx,args,iter,coefficients):
          def FedAvg(w):
               w_avg = copy.deepcopy(w[0])
               for k in w_avg.keys():
                    for i in range(1, len(w)):
                         w_avg[k] += w[i][k]
                    w_avg[k] = torch.div(w_avg[k], len(w))
               return w_avg
          w_locals=[]
          grads=[]
          for it, idx in enumerate(random_select_idx):
               local_weights = self.clients[idx].model.state_dict()
               local_grads=self.clients[idx].grads
               print(self.clients[idx].attack_flag,self.clients[idx].id)
               w_locals.append(local_weights)
               grads.append(local_grads)
          print('---------------------------------------------------------')
          if args.defense == 'trimmed':
               print('trimmed')
               w_glob = trimmed_mean(w_locals, args)
          elif args.defense == 'krum':
               print('krum')
               w_glob = krum(w_locals, args)
          elif args.defense == 'fltrust':
               print('fltrust')
               grad_g={}
               for name, param in self.model.named_parameters():
                    if param.grad != None:
                         grad_g[name] = param.grad
               w_glob = fltrust(w_locals, self.model.state_dict(), args,grads,grad_g,self._round)
          elif args.defense == 'byzan':
               print('byzan')
               w_glob = copy.deepcopy(w_locals[0])
               for k in w_glob.keys():
                    bulyan_local = []
                    for i in range(1, len(w_locals)):
                         bulyan_local.append(w_locals[i][k].cpu().numpy())
                    w_glob[k] = torch.tensor(bulyan(bulyan_local))
          elif args.defense == 'pca':
               print('pca')
               correct = []
               ack_num=3
               if iter < 11:
                    w_glob = FedAvg(w_locals)
                    torch.save(w_glob,
                               './pca_w/w_glob_{}.pth'.format(iter))
               else:
                    num = 0
                    attacker_ids = find_attacker(iter, random_select_idx, args)
                    this_round_idx = list(random_select_idx)
                    for i in range(len(attacker_ids)):
                         at_id = this_round_idx.index(attacker_ids[i])
                         if attacker_ids[i] in  self.random_select_attack:
                              num += 1
                         del w_locals[at_id]
                         del this_round_idx[at_id]
                    if ack_num != 0:
                         correct.append(num / ack_num)
                         print('Correct:', num / ack_num)
                    else:
                         correct.append(2)
                         print(
                              'There are no attackers in this round, and the alg chooses {} normal client:'.format(num))
                    if len(w_locals) != 0:
                         w_glob = FedAvg(w_locals)
                    else:
                         w_glob = torch.load('./pca_w/w_glob_{}.pth'.format(iter-1))

                    torch.save(w_glob, './pca_w/w_glob_{}.pth'.format(iter))
          self.model.load_state_dict(w_glob)
          print('--[defense]updated weights of {} clients are successfully averaged!'.format(len(random_select_idx)))



     def avg_model(self,random_select_idx,coefficients):

          w_avg=OrderedDict()
          for it, idx in enumerate(random_select_idx):
               local_weights = self.clients[idx].model.state_dict()
               for key in self.model.state_dict().keys():
                    if it == 0:
                         w_avg[key] = coefficients[it] * local_weights[key]
                    else:
                         w_avg[key] += coefficients[it] * local_weights[key]
          self.model.load_state_dict(w_avg)
          print('--updated weights of {} clients are successfully averaged!'.format(len(random_select_idx)))

     def clients_eval(self,random_select_idx):
          print('Evaluate selected {} client:'.format(len(random_select_idx)))
          for i,idx in enumerate(random_select_idx):
               self.clients[idx].eval()
          print('--Finished eval clients')

     def global_eval(self):
          self.model.eval()
          self.model.to(self.device)
          test_loss, correct ,len_data= 0, 0,0
          with torch.no_grad():
               for data, labels in self.test_loader:
                    data, labels = data.float().to(self.device), labels.long().to(self.device)
                    if self.args.datasets=='CIFAR10':
                         data=data.reshape(-1,3,32,32)
                    if self.args.datasets == 'fmnist':
                         data=data.reshape(-1,1,28,28)
                    outputs,_ = self.model(data,labels)
                    if self.args.LOSS=='MSE':
                         zero=torch.zeros(len(labels), self.args.num_classes)
                         zero=zero.to(self.device)
                         new_labels=zero.scatter_(1, labels.unsqueeze(1), 1)
                         new_labels=new_labels.to(self.device)
                         test_loss += self.loss_f(outputs, new_labels).item()
                    else:
                         # print(outputs.shape)
                         test_loss += self.loss_f(outputs, labels).item()
                    predicted = outputs.argmax(dim=1, keepdim=True)
                    correct += predicted.eq(labels.view_as(predicted)).sum().item()
                    len_data+=len(labels)

                    if self.device == "cuda": torch.cuda.empty_cache()
          self.model.to("cpu")

          test_loss = test_loss / len(self.test_loader)
          test_accuracy = correct / len_data
          return test_loss, test_accuracy

     def train_Fed(self,c_epoch):
          random_select_idx=self.select_client()
          self.send_model(random_select_idx)
          self.clients_update(random_select_idx,c_epoch)
          # self.clients_eval(random_select_idx)
          coefficients = [1 / len(random_select_idx)]*len(random_select_idx)
          # print(coefficients)
          if self.args.df:
               self.df(random_select_idx,self.args,c_epoch,coefficients)
          else:
               self.avg_model(random_select_idx,coefficients)

     def fit(self):
          print(f'[{str(self.args.algorithm)}]\n')
          self.result = {'loss': [], 'acc': []}
          loss_raw,acc_raw=self.global_eval()
          self.result['loss'].append(loss_raw)
          self.result['acc'].append(acc_raw)
          print(f'---[Round: {str(self._round)}]:raw_loss=', self.result['loss'])
          print(f'---[Round: {str(self._round)}]:raw_acc=', self.result['acc'])
          for rd in range(self.num_round):
               self._round=rd+1
               print('-------------------------------------------------------------')
               print(f"[Round: {str(self._round)}] --successfully initialized model\n")
               self.train_Fed(rd)
               loss,acc=self.global_eval()
               self.result['loss'].append(loss)
               self.result['acc'].append(acc)
               print(f'---[Round: {str(self._round)}]:loss=',self.result['loss'][-1])
               print(f'---[Round: {str(self._round)}]:acc=', self.result['acc'][-1])
          self.send_model(None)
          return self.result

















