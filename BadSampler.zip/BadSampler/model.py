import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import torch

class MLP(nn.Module):
    def __init__(self, dim_in, dim_hidden, dim_out):
        super(MLP, self).__init__()
        self.layer_input = nn.Linear(dim_in, dim_hidden)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout()
        self.layer_hidden = nn.Linear(dim_hidden, dim_out)

    def forward(self, x,y,buffer_up=False):
        #x = x.view(-1, x.shape[1]*x.shape[-2]*x.shape[-1])
        buffer = []
        y_true=[]
        x = x.view(-1, 6)
        x = self.layer_input(x)
        x = self.dropout(x)
        x = self.relu(x)
        x = self.layer_hidden(x)
        x = F.softmax(x)
        if buffer_up:
            for i in range(len(x)):
                buffer.append(x[i][y[i]].detach().cpu())
            y_true.extend(y)
        return x,buffer,y_true

# NET=MLP(6,128,2)
# a=torch.rand((10,6))
# b=torch.Tensor([1 for _ in range(10)])
# print(a)
# print(NET(a,b))




class CNN2(nn.Module):
    def __init__(self, name, in_channels, hidden_channels, num_hiddens, num_classes):
        super(CNN2, self).__init__()
        self.name = name
        self.activation = nn.ReLU(True)

        self.conv1 = nn.Conv2d(in_channels=in_channels, out_channels=hidden_channels, kernel_size=(5, 5), padding=1,
                               stride=1, bias=False)
        self.conv2 = nn.Conv2d(in_channels=hidden_channels, out_channels=hidden_channels * 2, kernel_size=(5, 5),
                               padding=1, stride=1, bias=False)

        self.maxpool1 = nn.MaxPool2d(kernel_size=(2, 2), padding=1)
        self.maxpool2 = nn.MaxPool2d(kernel_size=(2, 2), padding=1)
        self.flatten = nn.Flatten()

        self.fc1 = nn.Linear(in_features=(hidden_channels * 2) * (8 * 8), out_features=num_hiddens, bias=False)
        self.fc2 = nn.Linear(in_features=num_hiddens, out_features=num_classes, bias=False)

    def forward(self, x):
        x = self.activation(self.conv1(x))
        x = self.maxpool1(x)

        x = self.activation(self.conv2(x))
        x = self.maxpool2(x)
        x = self.flatten(x)

        h = self.activation(self.fc1(x))
        x = self.fc2(h)

        return h,x

class CNNMnist(nn.Module):
    def __init__(self, num_channels,num_classes):
        super(CNNMnist, self).__init__()
        self.conv1 = nn.Conv2d(num_channels, 10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv2_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, num_classes)

    def forward(self, x,y,buffer_up=False):
        buffer=[]

        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(-1, x.shape[1]*x.shape[2]*x.shape[3])
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        x=F.softmax(x)
        # print(x[0])
        if buffer_up:
            for i in range(len(x)):
                buffer.append(x[i].detach().cpu())

        return x,buffer


class CNNCifar(nn.Module):
    def __init__(self):
        super(CNNCifar, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self,x,y,buffer_up=False):
        buffer = []

        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 16 * 5 * 5)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        x = F.softmax(x)
        # print(x[0])
        if buffer_up:
            for i in range(len(x)):
                buffer.append(x[i].detach().cpu())

        return x,buffer


# def init_weights(model, args):
#
#
#     def init_func(m):
#         classname = m.__class__.__name__
#         if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
#             if args.initmethod == 'normal':
#                 init.normal_(m.weight.data, 0.0, args.init_gain)
#             elif args.initmethod == 'xavier':
#                 init.xavier_normal_(m.weight.data, gain=args.init_gain)
#             elif args.initmethod == 'kaiming':
#                 init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
#             else:
#                 raise NotImplementedError(f'[ERROR] ...initialization method [{args.args.initmethod}] is not implemented!')
#             if hasattr(m, 'bias') and m.bias is not None:
#                 init.constant_(m.bias.data, 0.0)
#
#         elif classname.find('BatchNorm2d') != -1 or classname.find('InstanceNorm2d') != -1:
#             init.normal_(m.weight.data, 1.0, args.init_gain)
#             init.constant_(m.bias.data, 0.0)
#
#         model.apply(init_func)
#
#
# def init_net(model, init_type):
#
#     init_weights(model, init_type)
#     return model