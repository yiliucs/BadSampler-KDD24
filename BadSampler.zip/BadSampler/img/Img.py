import matplotlib.pyplot as plt
from numpy import linspace


# def Print_local_img(args,loss_list,acc_list):
#     legend=[]
#     for i,loss in enumerate(loss_list):
#         plt.plot(linspace(0,args.local_epoch,len(loss)),loss)
#         legend.append('user{}'.format(i+1))
#     plt.legend(legend)
#     plt.show()
#     for i,acc in enumerate(acc_list):
#         plt.plot(linspace(0,args.local_epoch,len(acc)),acc)
#     plt.legend(legend,loc='best')
#     plt.show()


def global_plt(args,dict):

    # plt.plot(linspace(0,args.global_epoch,len(dict['loss'])),dict['loss'])
    # plt.legend(['loss'])
    # plt.show()
    # plt.savefig('./all_save/loss.png')
    plt.plot(linspace(0, args.global_epoch, len(dict['acc'])), dict['acc'])
    plt.legend(['acc'])
    plt.show()
    plt.savefig('./all_save/acc_cifar_MS_200_18.png')

# a=[[1,2,3],[1,3,4],[2,3,4]]
# b=[[1,2,3],[1,3,4],[2,3,4]]
# Print_local_img(args,a,b)
# plt.plot(linspace(0, 100, 100), [1 for _ in range(100)])
# plt.legend(['acc'])
# plt.show()