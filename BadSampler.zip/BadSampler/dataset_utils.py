import copy
from set import args
import numpy as np
import matplotlib.pyplot as plt
import torch
import torchvision.datasets as datasets
import torchvision.transforms as transforms
from torch.utils.data import Dataset
import torch.utils.data
import torchvision
# from model import *
# 设置随机数种子，保证相同的数据拆分,可获得结果的复现
np.random.seed(25)
# print('16')

class MYDataset(Dataset):
    def __init__(self, x, y):
        self._x = x
        self._y = y
        self._len = len(x)

    def __getitem__(self, item):  # 每次循环的时候返回的值
        img, label = self._x[item], self._y[item]
        # img=img.numpy()
        # img=img.reshape(3,32,32)
        # tf=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
        # tf= transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        # img = torch.Tensor(tf(img))
        img = torch.Tensor(img)

        # print(img)
        # img=img.reshape(3,32,32)
        return img, label

    def __len__(self):
        return self._len


def dirichlet_split_noniid(train_labels, alpha, n_clients):
    '''
    参数为 alpha 的 Dirichlet 分布将数据索引划分为 n_clients 个子集
    '''
    # 总类别数
    n_classes = train_labels.max()+1
    # [alpha]*n_clients 如下：
    # [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
    # 得到 62 * 10 的标签分布矩阵，记录每个 client 占有每个类别的比率
    label_distribution = np.random.dirichlet([alpha]*n_clients, n_classes)
    # 记录每个类别对应的样本下标
    # 返回二维数组
    class_idcs = [np.argwhere(train_labels==y).flatten()
           for y in range(n_classes)]

    # 定义一个空列表作最后的返回值
    client_idcs = [[] for _ in range(n_clients)]
    # 记录N个client分别对应样本集合的索引
    for c, fracs in zip(class_idcs, label_distribution):
        # np.split按照比例将类别为k的样本划分为了N个子集
        # for i, idcs 为遍历第i个client对应样本集合的索引
        for i, idcs in enumerate(np.split(c, (np.cumsum(fracs)[:-1]*len(c)).astype(int))):
            client_idcs[i] += [idcs]

    client_idcs = [np.concatenate(idcs) for idcs in client_idcs]

    return client_idcs


def Non_iid_spilt(DIRICHLET_ALPHA=0.1,N_CLIENTS = 10,datasets_name='cifar',R=True):
    # 初始化客户端数、参数α
    N_CLIENTS = N_CLIENTS
    DIRICHLET_ALPHA = DIRICHLET_ALPHA
    CLIENTS_idc={}
    CLIENTS_data={}
    CLIENTS_labels={}
    if datasets_name=='cifar':
        trans=transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
        train_data = datasets.CIFAR10(root="./datasets", transform=trans,download=False, train=True)
        train_img = train_data.data
        train_labels = np.array(train_data.targets)
    if datasets_name=='mnist':
        trans = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        train_data = datasets.MNIST(root="./datasets", transform=trans,download=True, train=True)
        train_img = train_data.data.numpy()
        train_labels = train_data.targets.numpy()
    if datasets_name=='fmnist':
        trans = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        train_data = datasets.FashionMNIST(root="./datasets", transform=trans,download=True, train=True)
        train_img = train_data.data.numpy()
        train_labels = train_data.targets.numpy()



    # print('ss',type(train_labels))


    client_idcs = dirichlet_split_noniid(train_labels, alpha=DIRICHLET_ALPHA, n_clients=N_CLIENTS)

    for i in range(N_CLIENTS):
        if R:
            np.random.shuffle(client_idcs[i])
        CLIENTS_idc[i]=client_idcs[i]
        CLIENTS_data[i]=train_img[client_idcs[i]]
        CLIENTS_labels[i]=train_labels[client_idcs[i]]

    # print(CLIENTS_labels)
    return CLIENTS_idc,CLIENTS_data,CLIENTS_labels

def Client_datasets_spilt(DIRICHLET_ALPHA=0.1,N_CLIENTS = 10,datasets_name='cifar'):
    CLIENTS_idc,CLIENTS_data,CLIENTS_labels=Non_iid_spilt(DIRICHLET_ALPHA, N_CLIENTS, datasets_name)
    CLIENT_train_x={}
    CLIENT_train_y = {}
    CLIENT_vaild_x={}
    CLIENT_vaild_y = {}
    for i in range(N_CLIENTS):
        CLIENT_train_x[i]=CLIENTS_data[i][0:int(len(CLIENTS_data[i])*(2/3))]
        CLIENT_train_y[i]=CLIENTS_labels[i][0:int(len(CLIENTS_data[i])*(2/3))]
        CLIENT_vaild_x[i] = CLIENTS_data[i][int(len(CLIENTS_data[i]) * (2 / 3)):-1]
        CLIENT_vaild_y[i] = CLIENTS_labels[i][int(len(CLIENTS_data[i]) * (2 / 3)):-1]
    # print(CLIENT_train_y)

    return CLIENT_train_x,CLIENT_train_y,CLIENT_vaild_x,CLIENT_vaild_y


def Train_vaild_loader(DIRICHLET_ALPHA=5,N_CLIENTS = 100,datasets_name=args.meta_set,bz=64):
    CLIENT_train_x, CLIENT_train_y, CLIENT_vaild_x, CLIENT_vaild_y=Client_datasets_spilt(DIRICHLET_ALPHA,N_CLIENTS ,datasets_name)
    # CLIENTS_idc,CLIENTS_data,CLIENTS_labels=Non_iid_spilt(DIRICHLET_ALPHA=1, N_CLIENTS=N_CLIENTS, datasets_name='mnist')
    # print(len(set(CLIENTS_labels[0])),set(CLIENTS_labels[0]),len(CLIENTS_labels[0]))
    Loader_client_train=[]
    Loader_client_vaild = []
    # print(CLIENT_train_y[0].shape)
    # Loader_Server=torch.utils.data.DataLoader(MYDataset(CLIENTS_data[0].reshape(-1,1,28,28),CLIENTS_labels[0]),batch_size=bz,shuffle=True)
    # print(CLIENTS_data[0].shape)
    # print(CLIENT_train_y[21])

    for i in range(N_CLIENTS):
        # CLIENT_train_x[i]=np.transpose(CLIENT_train_x[i],(0,3,1,2))
        # CLIENT_vaild_x[i]=np.transpose(CLIENT_vaild_x[i], (0, 3, 1, 2))
        # print(i)
        # print(CLIENT_train_x[i].shape)
        Loader_client_train.append(torch.utils.data.DataLoader(MYDataset(CLIENT_train_x[i],CLIENT_train_y[i]),batch_size=bz,shuffle=True))
        Loader_client_vaild.append(torch.utils.data.DataLoader(MYDataset(CLIENT_vaild_x[i],CLIENT_vaild_y[i]),batch_size=bz,shuffle=True))
    # trans = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
    # for x,y in Loader_client_train[0]:
    #     print(x)
    if datasets_name == 'fmnist':
        trans = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        test_data = datasets.FashionMNIST(root="./datasets", transform=trans, download=True, train=False)
    if datasets_name == 'mnist':
        trans = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        test_data = datasets.MNIST(root="./datasets", transform=trans, download=True, train=False)
    if datasets_name == 'cifar':
        trans = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
        test_data = datasets.CIFAR10(root="./datasets", transform=trans,download=True, train=False)

    test_loader=torch.utils.data.DataLoader(test_data,batch_size=bz,shuffle=True)
    return Loader_client_train,Loader_client_vaild,test_loader,\
           (CLIENT_train_x,CLIENT_train_y),(CLIENT_vaild_x,CLIENT_vaild_y)

#
# Loader_client_train,Loader_client_vaild,test_loader,\
#            (CLIENT_train_x,CLIENT_train_y),(CLIENT_vaild_x,CLIENT_vaild_y)=Train_vaild_loader()
# import torchvision
# for x,y in Loader_client_vaild[1]:
#     print(x.shape)
#     print(type(x[1]))
#     # img=x[2].numpy().reshape(32,32,3)
#     # img=np.transpose(img,(2,3,1))
#     # x=x.reshape(-1,3,32,32)
#     img = torchvision.utils.make_grid(x)
#     # img = torchvision.utils.make_grid(x)# 把64张图片拼接为1张图片
#     img = img.numpy().transpose(1, 2, 0)
#
#     print(y)
#     plt.imshow(img)
#     plt.savefig('./test_2.png')
#     plt.show()
#     break
#



def split_ten_class(data,label,label_num,min_class_idx,maj_class_idx,maj_num,min_num,valid_add_num):
    class_ = []
    idx = []
    data_all = []
    label_all = []
    # rand_list=[[1,3],[2,4],[6,8],[7,9],[5,10]]
    if type(data) == torch.Tensor:
        data = data.numpy()
    if type(label) == torch.Tensor:
        label = label.numpy()
    for i in range(label_num):
        class_.append([i] * (label == i).sum())
        idx.append(label == i)
        data_all.append(data[idx[i]])
        label_all.append(label[idx[i]])

    min_data={}
    min_label={}
    maj_data={}
    maj_label={}
    for i in min_class_idx:
        min_data[i]=data_all[i]
        min_label[i]=label_all[i]
    for i in maj_class_idx:
        maj_data[i]=data_all[i]
        maj_label[i]=label_all[i]
    min_data_train=np.concatenate(
        (min_data[min_class_idx[0]][0:min_num],min_data[min_class_idx[1]][0:min_num],min_data[min_class_idx[2]][0:min_num]))
    min_label_train = np.concatenate(
        (min_label[min_class_idx[0]][0:min_num], min_label[min_class_idx[1]][0:min_num], min_label[min_class_idx[2]][0:min_num]))

    maj_data_train=np.concatenate(
        (maj_data[maj_class_idx[0]][0:maj_num],maj_data[maj_class_idx[1]][0:maj_num]))
    maj_label_train = np.concatenate(
        (maj_label[maj_class_idx[0]][0:maj_num], maj_label[maj_class_idx[1]][0:maj_num]))
    for i in range(len(maj_class_idx)):
        if i==len(maj_class_idx)-2:
            break
        maj_data_train=np.concatenate((maj_data_train,maj_data[maj_class_idx[i+2]][0:maj_num]))
        maj_label_train=np.concatenate((maj_label_train, maj_label[maj_class_idx[i+2]][0:maj_num]))
    # print(len(maj_data_train))
    min_data_valid=np.concatenate(
        (min_data[min_class_idx[0]][1000:1000+valid_add_num],min_data[min_class_idx[1]][1000:1000+valid_add_num],min_data[min_class_idx[2]][1000:1000+valid_add_num]))
    min_label_valid = np.concatenate(
        (min_label[min_class_idx[0]][1000:1000+valid_add_num], min_label[min_class_idx[1]][1000:1000+valid_add_num], min_label[min_class_idx[2]][1000:1000+valid_add_num]))

    maj_data_valid = np.concatenate(
        (maj_data[maj_class_idx[0]][4000:5000], maj_data[maj_class_idx[1]][4000:5000]))
    maj_label_valid = np.concatenate(
        (maj_label[maj_class_idx[0]][4000:5000], maj_label[maj_class_idx[1]][4000:5000]))
    for i in range(len(maj_class_idx)):
        if i == len(maj_class_idx) - 2:
            break
        maj_data_valid = np.concatenate((maj_data_valid, maj_data[maj_class_idx[i + 2]][4000:5000]))
        maj_label_valid = np.concatenate((maj_label_valid, maj_label[maj_class_idx[i + 2]][4000:5000]))


    loader_maj_train=torch.utils.data.DataLoader(MYDataset(maj_data_train,maj_label_train),batch_size=32,shuffle=True)
    loader_min_train = torch.utils.data.DataLoader(MYDataset(min_data_train, min_label_train),batch_size=32,shuffle=True)
    loader_maj_valid = torch.utils.data.DataLoader(MYDataset(maj_data_valid, maj_label_valid),batch_size=32,shuffle=True)
    loader_min_valid = torch.utils.data.DataLoader(MYDataset(min_data_valid, min_label_valid),batch_size=32,shuffle=True)
    loader_valid_all = torch.utils.data.DataLoader(MYDataset(np.concatenate((maj_data_valid,min_data_valid)),
                                                             np.concatenate((maj_label_valid,min_label_valid))),batch_size=32,shuffle=True)
    loader_train_all = torch.utils.data.DataLoader(MYDataset(np.concatenate((maj_data_train,min_data_train)),
                                                             np.concatenate((maj_label_train,min_label_train))),batch_size=32,shuffle=True)

    return loader_maj_train,loader_min_train,loader_maj_valid,loader_min_valid,loader_valid_all,loader_train_all,(maj_data_train,maj_label_train),(min_data_train,min_label_train)













