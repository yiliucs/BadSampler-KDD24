import argparse

parser=argparse.ArgumentParser()
parser.add_argument('--algorithm',type=str,default='Fedattack')
parser.add_argument('--defense',type=str,default='fltrust')
parser.add_argument('--df',type=bool,default=False)
parser.add_argument('--meta_set',type=str,default='fmnist')
# # #System settings
parser.add_argument('--gpu',type=bool,default=True)
parser.add_argument('--device',default='cuda')
parser.add_argument('--save_path',type=str,default='./all_save')
parser.add_argument('--data_root',type=str,default='D:/limu/data')
parser.add_argument('--user_num',type=int,default=100)
parser.add_argument('--global_epoch',type=int,default=10)
parser.add_argument('--local_epoch',type=int,default=5)
# parser.add_argument('--model_path',type=str,default='./all_save/model')
# parser.add_argument('--txt_path',type=str,default='./all_save/loss_and_acc')
# parser.add_argument('--same_global_server',type=bool,default=True)
parser.add_argument('--fraction',type=float,default=0.1)
parser.add_argument('--seed',type=float,default=1)
#fedprox setting
parser.add_argument('--mu',type=float,default=5)
parser.add_argument('--T',type=float,default=0.5)
#LRstep setting
parser.add_argument('--step_size',type=float,default=1)
# parser.add_argument('--gamma',type=int,default=5)
#datasets settings
parser.add_argument('--datasets',type=str,default='fmnist')
parser.add_argument('--iid',type=bool,default=False)
parser.add_argument('--trans',type=int,default=1)
parser.add_argument('--DIRICHLET_ALPHA',type=float,default=0.3)
parser.add_argument('--N_COMPONENTS',type=float,default=-1)
parser.add_argument('--n_channels',type=int,default=1)
parser.add_argument('--num_cls',type=int,default=10)
parser.add_argument('--_idx',type=bool,default=False) #是否固定数据集
parser.add_argument('--save_idx',type=bool,default=True) #是否保存noniid 与noniid_idx一起使用
#train settings
# parser.add_argument('--lr',type=float,default=0.01)
# parser.add_argument('--batch_size',type=int,default=128)
parser.add_argument('--LOSS',type=str,default='CE')
parser.add_argument('--optim',type=str,default='Adam')
parser.add_argument('--weight_decay',type=float,default=0)
#cnn set
parser.add_argument('--net_select',type=str,default='CNN')
parser.add_argument('--server_net_select',type=str,default='CNN')
parser.add_argument('--in_channels',type=int,default=3)
parser.add_argument('--hidden_channels',type=int,default=32)
parser.add_argument('--num_hiddens',type=int,default=512)
parser.add_argument('--num_classes',type=int,default=2)
parser.add_argument('--init_gain',type=float,default=1.0)
parser.add_argument('--initmethod',type=str,default='xavier')

parser.add_argument('--sampler_bz',type=float,default=16)
parser.add_argument('--env-name', default="MESA-SAC")
parser.add_argument('--num_classer', default=10)
# SAC arguments
parser.add_argument('--policy', default="Gaussian",
                    help='Policy Type: Gaussian | Deterministic (default: Gaussian)')
parser.add_argument('--eval', type=bool, default=True,
                    help='Evaluates a policy every 10 episode (default: True)')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor for reward (default: 0.99)')
parser.add_argument('--tau', type=float, default=0.01, metavar='G',
                    help='target smoothing coefficient(τ) (default: 0.01)')
parser.add_argument('--lr', type=float, default=0.001, metavar='G',
                    help='learning rate (default: 0.001)')
parser.add_argument('--lr_decay_steps', type=int, default=10, metavar='N',
                    help='step_size of StepLR learning rate decay scheduler (default: 10)')
parser.add_argument('--lr_decay_gamma', type=float, default=0.99, metavar='N',
                    help='gamma of StepLR learning rate decay scheduler (default: 0.99)')
parser.add_argument('--alpha', type=float, default=0.1, metavar='G',
                    help='Temperature parameter α determines the relative importance of the entropy\
                            term against the reward (default: 0.1)')
parser.add_argument('--automatic_entropy_tuning', type=bool, default=False, metavar='G',
                    help='Automaically adjust α (default: False)')
# parser.add_argument('--seed', type=int, default=None, metavar='N',
#                     help='random seed (default: None)')
parser.add_argument('--batch_size', type=int, default=64, metavar='N',
                    help='batch size (default: 64)')
parser.add_argument('--hidden_size', type=int, default=50, metavar='N',
                    help='hidden size (default: 50)')
parser.add_argument('--updates_per_step', type=int, default=50, metavar='N',
                    help='model updates per simul|ator step (default: 1)')
parser.add_argument('--update_steps', type=int, default=5, metavar='N',
                    help='maximum number of steps (default: 1000)')
parser.add_argument('--start_steps', type=int, default=3, metavar='N',
                    help='Steps sampling random actions (default: 500)')
parser.add_argument('--target_update_interval', type=int, default=1, metavar='N',
                    help='Value target update per no. of updates per step (default: 1)')
parser.add_argument('--replay_size', type=int, default=1000, metavar='N',
                    help='size of replay buffer (default: 1000)')
parser.add_argument('--cuda', action="store_true", default=True,
                    help='run on CUDA (default: False)')

# MESA arguments
parser.add_argument('--reward_coefficient', type=float, default=100, metavar='N')
parser.add_argument('--num_bins', type=int, default=1, metavar='N',
                    help='number of bins (default: 5). state-size = 2 * num_bins.')
parser.add_argument('--sigma', type=float, default=0.2, metavar='N',
                    help='sigma of the Gaussian function used in meta-sampling (default: 0.2)')
parser.add_argument('--meta_verbose', type=int, default=10, metavar='N',
                    help='number of episodes between verbose outputs. \
                    If \'full\' print log for each base estimator (default: 10)')
parser.add_argument('--meta_verbose_mean_episodes', type=int, default=25, metavar='N',
                    help='number of episodes used for compute latest mean score in verbose outputs.')
parser.add_argument('--verbose', type=bool, default=False, metavar='N',
                    help='enable verbose when ensemble fit (default: False)')
parser.add_argument('--random_state', type=int, default=None, metavar='N',
                    help='random_state (default: None)')
parser.add_argument('--train_ir', type=float, default=1, metavar='N',
                    help='imbalance ratio of the training set after meta-sampling (default: 1)')
parser.add_argument('--train_ratio', type=float, default=1, metavar='N',
                    help='the ratio of the data used in meta-training. \
                    set train_ratio<1 to use a random subset for meta-training (default: 1)')



args=parser.parse_args()





