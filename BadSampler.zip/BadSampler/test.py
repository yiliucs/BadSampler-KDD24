from arguments import parser
import torchvision.datasets as datasets
import torchvision.transforms as transforms
from torch.utils.data import Dataset
import torch.utils.data
import numpy as np
import pandas as pd
import torch
args = parser.parse_args()

dict={1:[1,2],2:[32,4]}
for i in dict.keys():
    print(i)





