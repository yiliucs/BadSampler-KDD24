# -*- coding: utf-8 -*-
"""
Created on Sat Feb  8 02:27:20 2020
@author: ZhiningLiu1998
mailto: zhining.liu@outlook.com / v-zhinli@microsoft.com
"""
import copy
from collections import OrderedDict
import pandas as pd
import numpy as np
import sklearn
import warnings
import torch.utils.data
import torch
from dataset_utils import MYDataset
from model import *
import torch.optim
import torchvision
import matplotlib.pyplot as plt
import torchvision.transforms as transforms
warnings.filterwarnings("ignore")
# from dataset_utils import *
from utils import (
    Rater, meta_sampling, histogram_error_distribution, imbalance_train_test_split,histogram_error_distribution_cnn,
histogram_error_distribution_attack,histogram_error_distribution_attack_loss
    )


class EnsembleTrainingEnv():

    def __init__(self, args, base_net):
        # self.cifar_loader_test, self.cifar_loader_maj_train, self.cifar_loader_min_train, self.cifar_loader_valid_min, \
        # self.cifar_loader_valid_maj, self.cifar_data_max, \
        # self.cifar_data_min, self.cifar_loader_valid_all, self.cifar_loader_train_all = two_class_test_cifar()
        self.net=base_net
        self.args = args
        self.dataset=args.meta_set
        self.init_=None


    def load_data(self, loader_maj, loader_valid_maj,data_maj,
                                 loader_valid_all,loader_train_all,data_label,valid_label):
        self.maj_data_loader=loader_maj
        self.valid_data=loader_valid_maj
        self.maj_data=data_maj
        self.all_valid_data_loader=loader_valid_all
        self.all_train_data_loader=loader_train_all
        self.data_label=data_label
        self.valid_label=valid_label


    def init(self):
        self._warm_up()

    def get_logits(self,net,_dataset='fmnist',_type='train'):
        pred_buffer = []
        y_true=[]
        loss=0
        # data_x=[]
        loss_func = torch.nn.CrossEntropyLoss(reduction='sum')
        if _type=='train':
                x=self.maj_data
                y=self.data_label
                x=torch.Tensor(x/255)

                if _dataset=='fmnist':
                    x=x.reshape(-1,1,28,28).to(self.args.device)
                if _dataset=='cifar':
                    x = x.reshape(-1, 3, 32, 32).to(self.args.device)
                x=x.float().to(self.args.device)
                logits,buffer=net(x,y,buffer_up=True)
                loss +=loss_func(logits.cpu(), torch.Tensor(y).long()).item()
                pred_buffer.extend(buffer)
                y_true.extend(y.tolist())
        if _type=='valid':
                x = self.valid_data
                y = self.valid_label
                # tf = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
                # for i in x:
                #     i = tf(i)
                x = torch.Tensor(x/255)
                if _dataset=='fmnist':
                    x=x.reshape(-1,1,28,28).to(self.args.device)
                if _dataset == 'cifar':
                    x = x.reshape(-1, 3, 32, 32).to(self.args.device)
                x = x.float().to(self.args.device)
                logits,buffer=net(x,y,buffer_up=True)
                loss += loss_func(logits.cpu(), torch.Tensor(y).long()).item()
                pred_buffer.extend(buffer)
                y_true.extend(y.tolist())

        return pred_buffer,y_true,loss




    def get_state_cnn(self,net,_dataset):
        """Fetch the current state of the environment."""
        net.to(self.args.device)
        pred_buffer1,y_true_1,loss1 = self.get_logits(net,_dataset)
        pred_buffer2,y_true_2,loss2= self.get_logits(net,_dataset, _type='valid')
        hist1,hist2=histogram_error_distribution_attack_loss(
            loss1,loss2,5
        )
        # hist_train = histogram_error_distribution_cnn(
        #     pred_buffer1,
        #     y_true_1,
        #     self.args.num_bins)
        # print('hist_train',hist_train)
        # hist_valid = histogram_error_distribution_cnn(
        #     pred_buffer2,
        #     y_true_2,
        #     self.args.num_bins)
        # print(hist)
        # print(hist)
        hist1 = hist1 / len(self.maj_data) * self.args.num_bins
        hist2= hist2 / len(self.valid_data) * self.args.num_bins
        # hist=hist.reshape(1,2)

        # state = hist / hist.sum() * self.args.num_bins
        # print('shape',state.shape)
        # state2 = hist / hist.sum() * self.args.num_bins
        state = np.concatenate([hist1,hist2])
        state=state.reshape(2,)
        # print(state)
        # print(state.shape)
        # print(state)
        # print(state.shape)
        return state



    def cnn_train(self,net,loader,epoch,lr,data,valid_loader=None,test_loader=None):
        optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=0.9)
        loss_func=torch.nn.CrossEntropyLoss()
        for iter in range(epoch):
            for batch_idx, (images, labels) in enumerate(loader):
                if data=='cifar':
                    images=images.reshape(-1,3,32,32)
                if data=='fmnist':
                    images = images.reshape(-1, 1, 28, 28)
                images, labels = images.float().to(self.args.device), labels.long().to(self.args.device)
                net.zero_grad()
                log_probs,_ = net(images,labels)
                loss = loss_func(log_probs, labels)
                # print('loss',loss)
                loss.backward()
                optimizer.step()
        if valid_loader and test_loader :
            print('valid',self.cnn_score(net,valid_loader))
            print('test',self.cnn_score(net,test_loader))
        return net

    def cnn_score(self,net,loader,dataset,loss_=False):
        net.eval()
        net.to(self.args.device)
        correct = 0
        loss=0
        loss_func = torch.nn.CrossEntropyLoss(reduction='sum')
        for idx, (data, target) in enumerate(loader):
            if dataset == 'cifar':
                data = data.reshape(-1, 3, 32, 32)
            if dataset == 'fmnist':
                data = data.reshape(-1, 1, 28, 28)
            data, target = torch.tensor(data).to(self.args.device), torch.tensor(target).long().to(self.args.device)
            log_probs,_ = net(data,target)
            # print(log_probs.shape)
            # print(target.shape)
            loss +=loss_func(log_probs, target).item()
            y_pred = log_probs.data.max(1, keepdim=True)[1]
            correct += y_pred.eq(target.data.view_as(y_pred)).long().cpu().sum()
        accuracy =  correct / loader.dataset._len
        if loss_:
            return accuracy, loss
        else:
            return accuracy



    def one_shot_train_cnn(self,net,train_loader,valid_loader,test_loader,epoch,lr=0.001):
        print('start one shot test-------------------')
        f_net=self.cnn_train(net,train_loader,epoch,lr,valid_loader=valid_loader,test_loader=test_loader)

    def first_random_sam(self,net):
        first_net=copy.deepcopy(net).to(self.args.device)
        x = self.maj_data.reshape(len(self.maj_data), -1)
        # for e in range(int(self.all_train_data_loader.dataset._len/self.args.sampler_bz)):
        X_subset = pd.DataFrame(x).sample(self.args.sampler_bz)
        y_subset = pd.DataFrame(self.data_label).loc[X_subset.index.values]
        y_subset = y_subset.values.reshape(self.args.sampler_bz, )
        # X_subset = X_subset.values.reshape(len(y_subset), 32,32,3)
        X_subset = X_subset.values.reshape(len(y_subset), 28,28,1)


        train_dataset = MYDataset(X_subset, y_subset)
        train_first_loader = torch.utils.data.DataLoader(train_dataset, batch_size=32, shuffle=True)
        # print('--------------------------------------raw')
        first_net=self.cnn_train( first_net, train_first_loader, 10, 0.001, data=self.dataset)
        return first_net,train_first_loader

    def set_net(self):
        return copy.deepcopy(self.net).to(self.args.device)
    def avg_net(self,net,net_list):
        net_list.append(net.to('cpu'))
        w_avg = OrderedDict()
        for it, idx in enumerate(net_list):
            local_weights = idx.to('cpu').state_dict()
            for key in net.state_dict().keys():
                if it == 0:
                    w_avg[key] = (1/(len(net_list))) * local_weights[key]
                else:
                    w_avg[key] += (1/(len(net_list)+1)) * local_weights[key]
        net.load_state_dict(w_avg)
        return copy.deepcopy(net).to(self.args.device)

    def step_cnn(self, action, net, num, _dataset, net_list=None, verbose=True, raw_set=None):

        if action < 0 or action > 1:
            raise ValueError("Action must be a float in [0, 1].")

        if self.init_:
            # print('init--')
            raw_net, raw_train_dataset = self.first_random_sam(copy.deepcopy(net))
            self.init_ = False
        else:
            raw_net = net.to(self.args.device)
            raw_train_dataset = raw_set
        y_pre, y_true, _ = self.get_logits(raw_net, _dataset)
        # acc_before_t ,loss_b= self.cnn_score(raw_net, raw_train_dataset, dataset=self.dataset,loss_=True)
        # acc_before_v = self.cnn_score(raw_net, self.all_valid_data_loader, dataset=self.dataset)
        # print('acc_b', acc_before_v)

        # acc_before = torch.absolute(acc_before_t - acc_before_v)
        # sub=[]
        # new_cnn_net = self.set_net()
        # print('test',self.cnn_score(new_cnn_net,self.all_valid_data_loader,dataset=self.dataset))
        # for e in  range(int(self.all_train_data_loader.dataset._len/self.args.sampler_bz)):
        X_maj_subset, y_maj_subset = meta_sampling(
            y_pred=y_pre,
            y_true=y_true,
            n_under_samples=self.args.sampler_bz,
            X=self.maj_data,
            y=self.data_label,
            mu=action,
            sigma=self.args.sigma,
            random_state=self.args.random_state
        )


        subset_label = y_maj_subset.values.reshape(self.args.sampler_bz, )
        # sub.append(subset_label)
        # if len(sub)!=1:
        #     print('00000',sub[0]==sub[1])
        subset = X_maj_subset.values.reshape(len(subset_label), 28, 28, 1)
        train_dataset = MYDataset(subset, subset_label)
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=32, shuffle=True)

        ######------------?
        # print('111111')
        new_cnn_net = self.cnn_train(copy.deepcopy(raw_net), train_loader, 10, 0.001, data=self.dataset)
        # avg_net = self.avg_net(new_cnn_net, net_list)
        acc_before_t, loss_b = self.cnn_score(new_cnn_net, raw_train_dataset, dataset=self.dataset, loss_=True)
        acc_after_t, loss_a = self.cnn_score(new_cnn_net, train_loader, dataset=self.dataset, loss_=True)
        acc_before_v=self.cnn_score(raw_net, self.all_valid_data_loader, dataset=self.dataset)
        acc_after_v = self.cnn_score(new_cnn_net, self.all_valid_data_loader, dataset=self.dataset)
        state_cnn = self.get_state_cnn(new_cnn_net, _dataset=self.dataset)
        # print('loss_b', loss_b)
        # print('acc_f', acc_after_v)
        # print('loss_a', loss_a)

        reward = loss_a-loss_b
        # print('reward', reward)
        done = True
        info = ''

        # fetch environment information if verbose==True
        if verbose:
            acc_train = self.cnn_score(new_cnn_net, train_loader, dataset=self.dataset)
            acc_valid = self.cnn_score(new_cnn_net, self.all_valid_data_loader, dataset=self.dataset)

            # acc_test=self.cnn_score(avg_net,self.test_loader,dataset=self.dataset)
            # score_test = self.rater.score(self.y_test, self.y_pred_test_buffer) if self.flag_use_test_set else 'NULL'
            info = 'sample{}| train {:.3f} | valid {:.3f} | '.format(self.args.sampler_bz,
                                                                     acc_train, acc_valid)
            # info += 'test {:.3f}'.format(acc_test) if self.flag_use_test_set else 'test NULL'
            # info += 'test {:.3f}'.format(acc_test)
            # print(info)

        return state_cnn, reward, done, info, new_cnn_net.to('cpu'), train_loader



#--------------------------------------------------------------------------

    # def step_cnn(self, action, net,num,_dataset,net_list,verbose=True,raw_set=None):
    #
    #     if action < 0 or action > 1:
    #         raise ValueError("Action must be a float in [0, 1].")
    #
    #     if self.init_:
    #         print('init--')
    #         raw_net,raw_train_dataset=self.first_random_sam(copy.deepcopy(net))
    #         self.init_=False
    #     else:
    #         raw_net=net.to(self.args.device)
    #         raw_train_dataset=raw_set
    #     y_pre, y_true,_ = self.get_logits(raw_net, _dataset)
    #     # acc_before_t ,loss_b= self.cnn_score(raw_net, raw_train_dataset, dataset=self.dataset,loss_=True)
    #     acc_before_v = self.cnn_score(raw_net, self.all_valid_data_loader, dataset=self.dataset)
    #     print('acc_b',acc_before_v)
    #
    #     # acc_before = torch.absolute(acc_before_t - acc_before_v)
    #     # sub=[]
    #     new_cnn_net = self.set_net()
    #     # print('test',self.cnn_score(new_cnn_net,self.all_valid_data_loader,dataset=self.dataset))
    #     # for e in  range(int(self.all_train_data_loader.dataset._len/self.args.sampler_bz)):
    #     X_maj_subset,y_maj_subset = meta_sampling(
    #                 y_pred=y_pre,
    #                 y_true=y_true,
    #                 n_under_samples=1000,
    #                 X=self.maj_data,
    #                 y=self.data_label,
    #                 mu=action,
    #                 sigma=self.args.sigma,
    #                 random_state=self.args.random_state
    #             )
    #
    #     subset_label = y_maj_subset.values.reshape(1000,)
    #             # sub.append(subset_label)
    #             # if len(sub)!=1:
    #             #     print('00000',sub[0]==sub[1])
    #     subset=X_maj_subset.values.reshape(len(subset_label),32,32,3)
    #     train_dataset=MYDataset(subset,subset_label)
    #     train_loader=torch.utils.data.DataLoader(train_dataset,batch_size=32,shuffle=True)
    #
    #
    #      ######------------?
    #             # print('111111')
    #     new_cnn_net=self.cnn_train(copy.deepcopy(new_cnn_net),train_loader,100,0.01,data=self.dataset)
    #     avg_net = self.avg_net(new_cnn_net,net_list)
    #     acc_before_t, loss_b = self.cnn_score(avg_net, raw_train_dataset, dataset=self.dataset, loss_=True)
    #     acc_after_t,loss_a = self.cnn_score(avg_net, train_loader, dataset=self.dataset,loss_=True)
    #     acc_after_v = self.cnn_score(avg_net, self.all_valid_data_loader, dataset=self.dataset)
    #     state_cnn = self.get_state_cnn(avg_net,_dataset=self.dataset)
    #     print('loss_b', loss_b)
    #     print('acc_f', acc_after_v)
    #     print('loss_a', loss_a)
    #
    #     reward = loss_a-loss_b
    #     print('reward',reward)
    #     done = True if len(net_list)%self.args.num_classer==0 else False
    #     info = ''
    #
    #     # fetch environment information if verbose==True
    #     if  verbose:
    #
    #         acc_train=self.cnn_score(avg_net,train_loader,dataset=self.dataset)
    #         acc_valid=self.cnn_score(avg_net,self.all_valid_data_loader,dataset=self.dataset)
    #
    #         # acc_test=self.cnn_score(avg_net,self.test_loader,dataset=self.dataset)
    #         # score_test = self.rater.score(self.y_test, self.y_pred_test_buffer) if self.flag_use_test_set else 'NULL'
    #         info = 'sample{}| train {:.3f} | valid {:.3f} | '.format(self.args.sampler_bz,
    #               acc_train,  acc_valid)
    #         # info += 'test {:.3f}'.format(acc_test) if self.flag_use_test_set else 'test NULL'
    #         # info += 'test {:.3f}'.format(acc_test)
    #         # print(info)
    #
    #     return state_cnn, reward, done, info,avg_net.to('cpu'),train_loader

#-=--------------------------------------------------------------------------
    def step_cnn_client(self, action, net,_dataset,verbose=True):

        if action < 0 or action > 1:
            raise ValueError("Action must be a float in [0, 1].")

        y_pre,y_true,_=self.get_logits(net,_dataset)

        # perform meta-sampling
        X_maj_subset,y_maj_subset = meta_sampling(
            y_pred=y_pre,
            y_true=y_true,
            n_under_samples=self.args.sampler_bz,
            X=self.maj_data,
            y=self.data_label,
            mu=action,
            sigma=self.args.sigma,
            random_state=self.args.random_state
        )

        subset_label = y_maj_subset.values.reshape(self.args.sampler_bz,)
        subset = X_maj_subset.values.reshape(len(subset_label),32, 32,3)
        train_dataset = MYDataset(subset, subset_label)
        train_loader=torch.utils.data.DataLoader(train_dataset,batch_size=train_dataset._len)

        # acc_before=self.cnn_score(net,self.all_valid_data_loader,dataset=self.dataset)
        new_net=self.cnn_train(copy.deepcopy(net),train_loader,1,0.001,data=self.dataset)
        new_net.to(self.args.device)
        acc_after = self.cnn_score(new_net, self.all_valid_data_loader,dataset=self.dataset)
        state_cnn = self.get_state_cnn(new_net,_dataset=self.dataset)
        reward=None
        info = ''

        # fetch environment information if verbose==True
        if  verbose:

            acc_train=self.cnn_score(new_net,train_loader,dataset=self.dataset)
            # acc_test=self.cnn_score(new_net,self.test_loader,dataset=self.dataset)
            # score_test = self.rater.score(self.y_test, self.y_pred_test_buffer) if self.flag_use_test_set else 'NULL'
            # info = 'sample{}| train {:.3f} | valid {:.3f} | '.format(len(self.min_data),
            #       acc_train,  acc_after)
            # # info += 'test {:.3f}'.format(acc_test) if self.flag_use_test_set else 'test NULL'
            # info += 'test {:.3f}'.format(acc_test)
            # # print(info)

        return state_cnn, reward,  info,new_net


    
    def _warm_up(self):
        """Train the first base classifier with random under-sampling."""
        X_maj = self.X_train[self.mask_maj_train]
        X_min = self.X_train[self.mask_min_train]
        X_maj_rus = X_maj.sample(n=self.n_samples, random_state=self.args.random_state)
        # X_maj_rus = X_maj
        X_train_rus = pd.concat([X_maj_rus, X_min]).values
        y_train_rus = np.concatenate([np.zeros(X_maj_rus.shape[0]), np.ones(X_min.shape[0])])
        self.fit_step(X_train_rus, y_train_rus)
        self.update_all_pred_buffer()
        return