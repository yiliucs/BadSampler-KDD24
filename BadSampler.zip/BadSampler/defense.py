import copy
import torch
import numpy as np
from torch import nn
from collections import defaultdict




def trimmed_mean(w, args):
    number_to_consider = int((args.user_num - 20) * args.fraction) - 1
    print(number_to_consider)
    w_avg = copy.deepcopy(w[0])
    for k in w_avg.keys():
        tmp = []
        for i in range(len(w)):
            tmp.append(w[i][k].cpu().numpy()) # get the weight of k-layer which in each client
        tmp = np.array(tmp)
        med = np.median(tmp,axis=0)
        new_tmp = []
        for i in range(len(tmp)):# cal each client weights - median
            new_tmp.append(tmp[i]-med)
        new_tmp = np.array(new_tmp)
        good_vals = np.argsort(abs(new_tmp),axis=0)[:number_to_consider]
        good_vals = np.take_along_axis(new_tmp, good_vals, axis=0)
        k_weight = np.array(np.mean(good_vals) + med)
        w_avg[k] = torch.from_numpy(k_weight)
    return w_avg


def krum(w, args):
    distances = defaultdict(dict)
    non_malicious_count = int((args.user_num - 20) * args.fraction)
    num = 0
    for k in w[0].keys():
        if num == 0:
            for i in range(len(w)):
                for j in range(i):
                    distances[i][j] = distances[j][i] = np.linalg.norm(w[i][k].cpu().numpy() - w[j][k].cpu().numpy())
            num = 1
        else:
            for i in range(len(w)):
                for j in range(i):
                    distances[j][i] += np.linalg.norm(w[i][k].cpu().numpy() - w[j][k].cpu().numpy())
                    distances[i][j] += distances[j][i]
    minimal_error = 1e20
    for user in distances.keys():
        errors = sorted(distances[user].values())
        current_error = sum(errors[:non_malicious_count])
        if current_error < minimal_error:
            print(user)
            minimal_error = current_error
            minimal_error_index = user
    return w[minimal_error_index]


def fltrust(w, w_global, args,grads,grad_g,r):
    n = len(w)
    baseline = w_global

    # print(grad_g)
    # print(grads[0])
    cos_grad = []
    for name in grads[0]:
        print(grads[0][name].shape)
    p0=grads[0]
    p1=grads[1]
    p2=grads[2]
    p3 = grads[3]
    p4 = grads[4]
    # print(p2)
    cos_grad_n = []

    cos = nn.CosineSimilarity(dim=-1)
    for k in p0.keys():
        cos_g_n = 0
        cos_g_n+=cos(torch.flatten(p3[k], end_dim=-1).float(),
                                     torch.flatten(p2[k], end_dim=-1).float())
        cos_grad_n.append(cos_g_n)
    print('cos_n',cos_grad_n)
    # for k in p0.keys():
    #     cos_g_n += torch.dot(torch.flatten(p0[k], end_dim=-1).float(),
    #                                  torch.flatten(p1[k], end_dim=-1).float()) / (
    #                                torch.norm(torch.flatten(p0[k], end_dim=-1).float()) + 1e-9) / (
    #                                torch.norm(torch.flatten(p1[k], end_dim=-1).float()) + 1e-9)
    # cos_grad.append(cos_g_n)
    cos_grad_a = []

    for k in p0.keys():
        cos_g_a = 0
        cos_g_a+=cos(torch.flatten(p3[k], end_dim=-1).float(),
                                     torch.flatten(p4[k], end_dim=-1).float())
        cos_grad_a.append(cos_g_a)
    print('cos_a', cos_grad_a)
    # for k in p0.keys():
    #     cos_g_a += torch.dot(torch.flatten(p2[k], end_dim=-1).float(),
    #                                  torch.flatten(p1[k], end_dim=-1).float()) / (
    #                                torch.norm(torch.flatten(p2[k], end_dim=-1).float()) + 1e-9) / (
    #                                torch.norm(torch.flatten(p1[k], end_dim=-1).float()) + 1e-9)
    # cos_grad.append(cos_g_a)
    # print('cos_grad:',cos_grad)

    # for p in grads:
    #     cos_g = 0
    #     for k in p.keys():
    #         cos_g += torch.dot(torch.flatten(grad_g[k], end_dim=-1).float(),
    #                                  torch.flatten(p[k], end_dim=-1).float()) / (
    #                                torch.norm(torch.flatten(grad_g[k], end_dim=-1).float()) + 1e-9) / (
    #                                torch.norm(torch.flatten(p[k], end_dim=-1).float()) + 1e-9)
    #     cos_grad.append(cos_g)
    # print('cos_grad:',cos_grad)

    cos_sim = []
    for param in w:
        cos_tmp = 0
        for k in param.keys():
            cos_tmp += torch.dot(torch.flatten(baseline[k], end_dim=-1).float(),
                                 torch.flatten(param[k], end_dim=-1).float()) / (
                                   torch.norm(torch.flatten(baseline[k], end_dim=-1).float()) + 1e-9) / (
                                   torch.norm(torch.flatten(param[k], end_dim=-1).float()) + 1e-9)
        cos_sim.append(cos_tmp)
    print('cos_sim:',cos_sim)
    good_result = []
    for i in cos_sim:
        if i > 0:  # relu
            good_result.append(i.cpu().numpy())
        else:
            good_result.append(0.)
    good_result = np.array(good_result)
    print(good_result)
    if np.sum(good_result) == 0:
        normalized_weights = [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1]
    else:
        normalized_weights = good_result / (np.sum(good_result) + 1e-9)
    print(normalized_weights)
    new_param_list = []
    for k in w[0].keys():
        tmp = []
        for i in range(n):  # each client
            # print(torch.mul(w[i][k],normalized_weights[i]))
            '''
            tmp.append(torch.mul(torch.div(torch.mul(w[i][k], normalized_weights[i])
                                           , (torch.norm(torch.flatten(w[i][k], end_dim=-1).float()) + 1e-9))
                                 , torch.norm(torch.flatten(baseline[k], end_dim=-1).float())))
            '''
            tmp.append(torch.mul(w[i][k], normalized_weights[i]))
        new_param_list.append(sum(tmp))
    w_avg = copy.deepcopy(w[0])
    num = 0
    for k in w_avg.keys():
        w_avg[k] = new_param_list[num]
        num += 1
    return w_avg