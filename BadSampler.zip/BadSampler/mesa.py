# -*- coding: utf-8 -*-
"""
Created on Sat Feb  8 02:27:20 2020
@author: ZhiningLiu1998
mailto: zhining.liu@outlook.com / v-zhinli@microsoft.com
"""
import copy
import os
import torch
import torchvision
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from gym import spaces
from sac_src.sac import SAC
from sac_src.replay_memory import ReplayMemory
from environment import EnsembleTrainingEnv
from utils import *
from tqdm import tqdm
# from dataset_utils import *

# class Mesa():
#
#     def __init__(self,args,net,meta_loader,meta_train_data,meta_valid_data):
#
#         state_size = int(2*args.num_bins)
#         # print('statesize',state_size)
#         action_space = spaces.Box(low=0.0, high=1.0, shape=[1], dtype=np.float32)
#
#         self.args = args
#         self.net=net
#         self.meta_sampler = SAC(state_size, action_space, self.args)
#         self.env = EnsembleTrainingEnv(args, copy.deepcopy(self.net))
#         self.memory = ReplayMemory(self.args.replay_size)
#         self.loader_maj=meta_loader[0]
#         self.valid_data=meta_valid_data[0]
#         self.valid_label=meta_valid_data[1]
#         self.data_maj=meta_train_data[0]
#         self.data_label=meta_train_data[1]
#         self.loader_valid_all=meta_loader[1]
#         self.loader_train_all=meta_loader[0]

class Mesa():

    def __init__(self,args,net,local_data,valid_data, train_data,
                                               train_label,valid_img,valid_label):

        state_size = int(2*args.num_bins)
        # print('statesize',state_size)
        action_space = spaces.Box(low=0.0, high=1.0, shape=[1], dtype=np.float32)

        self.args = args
        self.net=net
        self.meta_sampler = SAC(state_size, action_space, self.args)
        self.env = EnsembleTrainingEnv(args, copy.deepcopy(self.net))
        self.memory = ReplayMemory(self.args.replay_size)
        self.loader_maj=local_data
        self.valid_data=valid_img
        self.valid_label=valid_label
        self.data_maj=train_data
        self.data_label=train_label
        self.loader_valid_all=valid_data
        self.loader_train_all=local_data
        self.grads={}
    def meta_fit(self):


        self.env.load_data(self.loader_maj, self.valid_data, self.data_maj
                           , self.loader_valid_all, self.loader_train_all, self.data_label, self.valid_label)
        self.memory = memory_init_fulfill(self.args, ReplayMemory(self.args.replay_size))

        self.scores = []
        total_steps = self.args.update_steps + self.args.start_steps
        # total_steps=self.args.local_epoch*(int(self.loader_maj.dataset._len/self.args.sampler_bz))
        print('total_size',total_steps)
        num_steps, num_updates, num_episodes = 0, 0, 0
        # self.env.one_shot_train_cnn(copy.deepcopy(self.net), self.loader_train_all, self.loader_valid_all,
        #                             self.loader_test, 100)

        while num_steps < total_steps:
            # print(num_steps)
            state_cnn = self.env.get_state_cnn(self.net, _dataset=self.args.meta_set)

            self.net_list = []
            self.loader_list = []
            self.env.init_ = True
            # print('stac',state_cnn)
            done = False
            # for each episode
            while not done:
                num_steps += 1
                # take an action
                if num_steps >= self.args.start_steps:
                    action, by = self.meta_sampler.select_action(state_cnn), 'mesa'
                else:
                    action, by = self.meta_sampler.action_space.sample(), 'rand'

                if self.env.init_:
                    next_state, reward, done, info, self.net, train_loader = self.env.step_cnn(action[0],
                                                                                          net=copy.deepcopy(self.net).to(self.args.device),
                                                                                          num=num_steps,
                                                                                          _dataset=self.args.meta_set,
                                                                                          )
                    # self.net_list.append(copy.deepcopy(net))
                    self.loader_list.append(train_loader)
                next_state, reward, done, info, self.net, train_loader = self.env.step_cnn(action[0],
                                                                                      net=self.net,
                                                                                      num=num_steps, _dataset=self.args.meta_set,

                                                                                      raw_set=self.loader_list[-1])
                # self.net_list.append(copy.deepcopy(net))
                self.loader_list.append(train_loader)
                # print('len',len(self.net_list))
                reward = reward * self.args.reward_coefficient
                self.memory.push(state_cnn, action, reward, next_state, float(done))

                # update meta-sampler parameters
                if num_steps > self.args.start_steps:
                    # print('start update sampler')
                    for i in range(self.args.updates_per_step):
                        _, _, _, _, _ = self.meta_sampler.update_parameters(
                            self.memory, self.args.batch_size, num_updates)
                        num_updates += self.args.updates_per_step

                # print log to stdout
                if self.args.meta_verbose is 'full':
                    print('Epi.{:<4d} updates{:<4d}| {} | {} by {}'.format(num_episodes, num_updates, info, action[0],
                                                                           by))

                if done:
                    num_episodes += 1
                    # print('acc_test',self.env.cnn_score(self.net,self.loader_test,self.env.dataset))
        self.net.to("cpu")
        for name, param in self.net.named_parameters():
            if param.grad != None:
                self.grads[name] = param.grad
        return self.net,self.grads







    #--------------------------------------------------------------------------------
    # def meta_fit(self):
    #
    #     self.env.load_data( self.loader_maj,  self.valid_data,self.data_maj
    #                              ,self.loader_valid_all,self.loader_train_all,self.data_label,self.valid_label)
    #     self.memory = memory_init_fulfill(self.args, ReplayMemory(self.args.replay_size))
    #
    #     self.scores = []
    #     total_steps = self.args.update_steps + self.args.start_steps
    #     num_steps, num_updates, num_episodes = 0, 0, 0
    #     # self.env.one_shot_train_cnn(copy.deepcopy(self.net), self.loader_train_all, self.loader_valid_all,
    #     #                             self.loader_test, 100)
    #
    #     while num_steps < total_steps:
    #         # print(num_steps)
    #         state_cnn=self.env.get_state_cnn(self.net,_dataset='cifar')
    #
    #         self.net_list = []
    #         self.loader_list=[]
    #         self.env.init_=True
    #         # print('stac',state_cnn)
    #         done = False
    #         # for each episode
    #         while not done:
    #             num_steps += 1
    #             # take an action
    #             if num_steps >= self.args.start_steps:
    #                 action, by = self.meta_sampler.select_action(state_cnn), 'mesa'
    #             else:
    #                 action, by = self.meta_sampler.action_space.sample(), 'rand'
    #
    #             if self.env.init_:
    #                 next_state, reward, done, info,net,train_loader = self.env.step_cnn(action[0],net=copy.deepcopy(self.net).to(self.args.device),
    #                                                                             num=num_steps,_dataset='cifar',net_list=copy.deepcopy(self.net_list))
    #                 self.net_list.append(copy.deepcopy(net))
    #                 self.loader_list.append(train_loader)
    #             next_state, reward, done, info, net,train_loader = self.env.step_cnn(action[0],
    #                                                                          net=self.net_list[-1],
    #                                                                          num=num_steps, _dataset='cifar',net_list=copy.deepcopy(self.net_list),
    #                                                                         raw_set=self.loader_list[-1])
    #             self.net_list.append(copy.deepcopy(net))
    #             self.loader_list.append(train_loader)
    #             # print('len',len(self.net_list))
    #             reward = reward * self.args.reward_coefficient
    #             self.memory.push(state_cnn, action, reward, next_state, float(done))
    #
    #             # update meta-sampler parameters
    #             if num_steps > self.args.start_steps:
    #                 # print('start update sampler')
    #                 for i in range(self.args.updates_per_step):
    #                     _, _, _, _, _ = self.meta_sampler.update_parameters(
    #                         self.memory, self.args.batch_size, num_updates)
    #                     num_updates += self.args.updates_per_step
    #
    #             # print log to stdout
    #             if self.args.meta_verbose is 'full':
    #                 print ('Epi.{:<4d} updates{:<4d}| {} | {} by {}'.format(num_episodes, num_updates, info, action[0], by))
    #
    #             if done:
    #                 num_episodes += 1
    #                 # print('acc_test',self.env.cnn_score(self.net,self.loader_test,self.env.dataset))
    #
    #     return self
    #--------------------------------------------------------------------------------

    def fit(self,client_net,epoch,id,local_data,valid_data):
        self.env.maj_data=local_data.dataset._x
        self.env.data_label=local_data.dataset._y
        self.env.valid_data=valid_data.dataset._x
        self.env.valid_label=valid_data.dataset._y
        self.env.all_valid_data_loader=valid_data
        self.env.all_train_data_loader=local_data
        self.client_net=client_net
        self.env.net=self.client_net
        self.client_net.to(self.args.device)
        self.actions_record = []
        self.env.dataset='fmnist'
        for i in tqdm(range(epoch), desc='--client {} is updating'.format(id)):
            for i in range(int(self.env.all_train_data_loader.dataset._len/self.args.sampler_bz)):
                state = self.env.get_state_cnn(self.client_net,_dataset='fmnist')
                action = self.meta_sampler.select_action(state)
                self.actions_record.append(action[0])
                _, _,  info,self.client_net = self.env.step_cnn_client(action[0],self.client_net,_dataset='fmnist')

        return self.client_net
    
    def save_meta_sampler(self, directory='save_model', suffix='meta_sampler'):
        """Save trained meta-sampler to files.

        Parameters
        ----------
        directory : string, optional (default='save_model')
            The directory to save files.
            Create the directory if it does not exist.

        suffix : string, optional (default='meta_sampler')
            The actor network will be saved in {directory}/actor_{suffix}.
            The critic network will be saved in {directory}/critic_{suffix}.
        """
        directory_path = f'{directory}/'
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
        actor_path = f'{directory_path}actor_{suffix}'
        critic_path = f'{directory_path}critic_{suffix}'
        self.meta_sampler.save_model(actor_path, critic_path)
        return
        
    def load_meta_sampler(self, directory='save_model', suffix='meta_sampler'):
        """Load trained meta-sampler from files.
        
        Parameters
        ----------
        directory : string, optional (default='save_model')
            The directory to load files.

        suffix : string, optional (default='meta_sampler')
            The actor network will be loaded from {directory}/actor_{suffix}.
            The critic network will be loaded from {directory}/critic_{suffix}.
        """
        directory_path = f'{directory}/'
        actor_path = f'{directory_path}actor_{suffix}'
        critic_path = f'{directory_path}critic_{suffix}'
        self.meta_sampler.load_model(actor_path, critic_path)
        return self