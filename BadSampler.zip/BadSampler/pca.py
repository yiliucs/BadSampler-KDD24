import torch
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import json
import os
from sklearn.cluster import KMeans
import numpy as np
from collections import Counter
import random


def apply_standard_scaler(params):
    # print(params)
    scaler = StandardScaler()
    return scaler.fit_transform(params)


def calculate_pca_of_models(params, num_components):
    pca = PCA(n_components=num_components)
    return pca.fit_transform(params)

def get_layer_parameters(parameters, layer_name):
    """
    Get a specific layer of parameters from a parameters object.

    :param parameters: dict(tensor)
    :param layer_name: string
    """
    return parameters[layer_name]

def calculate_parameter_models(params_1, params_2):
    """
    Calculates the gradient (parameter difference) between two sets of Torch parameters.

    :param model_1: dict
    :param model_2: dict
    """

    return np.array([x for x in np.subtract(params_1, params_2)])

def read_weight(path):
    with open(path,'r') as f:
        param = json.load(f)
    return param

def find_attacker(iter, idx_users, args):
    param_diff = []
    worker_ids = []
    CLASS_NUM = random.randint(0,9)
    if args.net_select =='cnn' and args.datasets =='fmnist':
        LAYER_NAME = 'fc2.weight'
    elif args.net_select == 'CNN2' and args.datasets =='CIFAR10':
        LAYER_NAME = 'fc3.weight'
    elif args.net_select == 'resnet':
        LAYER_NAME = 'fc.weight'
    elif args.net_select == 'lr':
        LAYER_NAME = 'linear.weight'
    EPOCHS = list(range(1, iter))
    for epoch in EPOCHS:
        before_global = torch.load('./pca_w/w_glob_{}.pth'.format(epoch-1)) #read the (t-1)th global
        # print('----swadasd',before_global)
        start_model_layer_param = list(get_layer_parameters(before_global, LAYER_NAME)[CLASS_NUM].cpu())

        for id in idx_users:
            if os.path.exists('./pca_w/client_{}_{}.pth'.format(epoch,id)):# judge the model is exist
                local_model = torch.load('./pca_w/client_{}_{}.pth'.format(epoch, id))
                end_model_layer_param = list(get_layer_parameters(local_model, LAYER_NAME)[CLASS_NUM].cpu())
                model = calculate_parameter_models(start_model_layer_param, end_model_layer_param)
                model = model.flatten()
                param_diff.append(model)
                # print(param_diff)
                worker_ids.append(id)
    worker_ids=np.array(worker_ids)
    scaled_param_diff = apply_standard_scaler(param_diff)
    dim_reduce_models = calculate_pca_of_models(scaled_param_diff, 2)
    #print("Dimensionally-reduced models shape: ({}, {})".format(len(dim_reduce_models), dim_reduce_models[0].shape[0]))
    kmeans_model = KMeans(n_clusters=2)
    kmeans_model.fit(dim_reduce_models)
    yhat = kmeans_model.predict(dim_reduce_models)
    attacker_cluster = np.argmin(np.bincount(yhat))#find the attacker cluster, min
    attacker_params_index = np.where(yhat == attacker_cluster)# find the index of params
    attacker_ids = list(set(worker_ids[attacker_params_index]))
    print(attacker_params_index)
    print(attacker_ids)
    # attacker_id = np.argmax(np.bincount(attacker_ids))
    print('detect the attacker is: {}'.format(attacker_ids))
    # if attacker_id == 3:
    #     args.num += 1
    # print('Now correct:',args.num)
    return attacker_ids